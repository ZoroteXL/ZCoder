with open("system/bg_color.py", "a") as f:
    f.write("\nCOLORNAME = 'CYAN'")