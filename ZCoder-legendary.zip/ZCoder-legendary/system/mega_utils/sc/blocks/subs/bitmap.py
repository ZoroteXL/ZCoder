from ...block import ScBlock



class ShapeDrawBitmap(ScBlock):
	def __init__(self, tag: int, textures: list):
		super().__init__(tag)
		
		self.textures = textures
	
	def parse(self, data: bytes):
		super().parse(data)
		
		bitmap = {}
		
		bitmap["TexNum"] = self.readUByte()
		
		bitmap["Is Rectangular"] = False
		if self.tag == 4:
			bitmap["Is Rectangular"] = True
			points_count = 4
		else:
			points_count = self.readUByte()
		
		bitmap["points"] = []
		
		for i in range(points_count):
			# twips XY
			x = self.readInt32() / 20
			y = self.readInt32() / 20
			
			bitmap["points"].append({
				"twip": [x, y],
				"uv": [0, 0]
			})
		
		for i in range(points_count):
			# texture UV
			u = self.readUShort()
			v = self.readUShort()
			
			if self.tag == 22:
				u /= 65535
				v /= 65535
				
				u *= self.textures[bitmap["TexNum"]]["width"]
				v *= self.textures[bitmap["TexNum"]]["height"]
			
			bitmap["points"][i]["uv"] = [round(u), round(v)]
		
		return bitmap
	
	def encode(self, bitmap: dict):
		super().encode()
		
		self.writeUByte(bitmap["TexNum"])
		
		if not bitmap["Is Rectangular"]:
			self.writeUByte(len(bitmap["points"]))
		
		for point in bitmap["points"]:
			x = point["twip"][0] * 20
			y = point["twip"][1] * 20
			
			self.writeInt32(round(x))
			self.writeInt32(round(y))
		
		for point in bitmap["points"]:
			u = point["uv"][0]
			v = point["uv"][1]
			
			if self.tag == 22:
				u *= 65535
				v *= 65535
				
				u /= self.textures[bitmap["TexNum"]]["width"]
				v /= self.textures[bitmap["TexNum"]]["height"]
			
			self.writeUShort(round(u))
			self.writeUShort(round(v))
		
		self.length = len(self.stream.buffer)
