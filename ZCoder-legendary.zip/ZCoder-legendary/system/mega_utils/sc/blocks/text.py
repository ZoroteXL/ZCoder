from ..block import ScBlock



class TextField(ScBlock):
	def __init__(self, tag: int):
		super().__init__(tag)
	
	def parse(self, data: bytes):
		super().parse(data)
		
		text = {}
		
		text["id"] = self.readUShort()
		
		text["Font"] = self.readString()
		text["Rgba and Optically"] = [self.readNUByte() for x in range(4)]
		
		text["Bool1"] = self.readBool()
		text["Bool2"] = self.readBool()
		text["Bool3"] = self.readBool()
		text["Bool4"] = self.readBool()
		
		text["Byte1"] = self.readByte()
		text["Byte2"] = self.readByte()
		
		text["Short1"] = self.readShort()
		text["Short2"] = self.readShort()
		text["Short3"] = self.readShort()
		text["Short4"] = self.readShort()
		
		text["Bool5"] = self.readBool()
		
		text["Text"] = self.readString()
		if self.tag == 7:
			return text
		
		text["Extra"] = {}
		extra = text["Extra"]
		
		extra["Bool6"] = self.readBool()
		if self.tag in [21, 25, 33, 44]:
			extra["Rgba and Optically"] = [self.readNUByte() for x in range(4)]
		elif self.tag == 20:
			return text
		
		if self.tag in [33, 44]:
			extra["Short5"] = self.readShort()
			extra["Short6"] = self.readShort()
			
			if self.tag == 44:
				extra["Short7"] = self.readShort()
				extra["Bool7"] = self.readBool()
		
		return text
	
	def encode(self, text: dict):
		super().encode()
		
		self.writeUShort(text["id"])
		
		self.writeString(text["Font"])
		
		self.writeNUByte(text["Rgba and Optically"][0])
		self.writeNUByte(text["Rgba and Optically"][1])
		self.writeNUByte(text["Rgba and Optically"][2])
		self.writeNUByte(text["Rgba and Optically"][3])
		
		self.writeBool(text["Bool1"])
		self.writeBool(text["Bool2"])
		self.writeBool(text["Bool3"])
		self.writeBool(text["Bool4"])
		
		self.writeByte(text["Byte1"])
		self.writeByte(text["Byte2"])
		
		self.writeShort(text["Short1"])
		self.writeShort(text["Short2"])
		self.writeShort(text["Short3"])
		self.writeShort(text["Short4"])
		
		self.writeBool(text["Bool5"])
		self.writeString(text["Text"])
		
		if "extra" in text:
			self.tag = 15
			
			extra = text["extra"]
			
			self.writeBool(extra[" Bool6"])
			
			if "Rgba and Optically" in extra:
				self.tag = 21
				
				self.writeNUByte(extra["Rgba and Optically"][0])
				self.writeNUByte(extra["Rgba and Optically"][1])
				self.writeNUByte(extra["Rgba and Optically"][2])
				self.writeNUByte(extra["Rgba and Optically"][3])
			
			if "Short5" and "Short6" in extra:
				self.tag = 33
				
				self.writeShort(extra["Short5"])
				self.writeShort(extra["Short6"])
				
				if " Short7" and " Bool7" in extra:
					self.tag = 44
					
					self.writeShort(extra[" Short7"])
					self.writeBool(extra[" Bool7"])
		
		self.length = len(self.stream.buffer)
