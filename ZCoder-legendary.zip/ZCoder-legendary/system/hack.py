import os
import sys
import json
import urllib
import time
import socket
import subprocess
import csv
import requests

from pathlib import Path
from urllib import request
from requests import get
from tqdm import tqdm
from csv import reader, writer
	
if not os.path.isdir("csv"):
	os.mkdir("csv")

while True:
	a = input("Хаки\n1) Открыть все спреи (визуально)\n2) Открыть скрытые сообщения в чате (визуально)\n3) Открыть скрытую эмодзи\n4) Открыть иконки профиля (визуально)\n5) Работа с skins.csv\n6) Открыть закрытые карты и некоторые режимы\n7) Открыть скрытые пасивки и гаджеты (может быть баг!)\n\n0) Назад\n---> ")
		
	clear()
	if a =="1":
		file = list(csv.reader(open("system/files/sprays.csv", "r")))
		a = file[0].index("Rarity")
	
		for i in file:
			if i[a] == "COLLECTORS":
				i[a] = "DEFAULT"
				
		b = file[0].index("Rarity")
	
		for i in file:
			if i[a] == "COMMON":
				i[a] = "DEFAULT"				
	
		with open("csv/sprays.csv","w") as f:
			writer = csv.writer(f)
			for i in file:
				writer.writerow(i)
		print("\033[32m\033[1mВсе спреи открыты!\033[0m")
		
	elif a =="2":
		file = list(csv.reader(open("system/files/messages.csv", "r")))
		a = file[0].index("Disabled")
		
		for i in file:
			if i[a] == "TRUE":
				i[a] = ""
	
		with open("csv/messages.csv","w") as f:
			writer = csv.writer(f)
			for i in file:
				writer.writerow(i)
		print("\033[32m\033[1mСкрытые сообщения в чате открыты!\033[0m")
		
	elif a =="3":
		file = list(csv.reader(open("system/files/emotes.csv", "r")))
		a = file[0].index("IsDefaultBattleEmote")
		
		for i in file:
			if i[a] == "TRUE":
				i[a] = ""
	
		with open("csv/emotes.csv","w") as f:
			writer = csv.writer(f)
			for i in file:
				writer.writerow(i)
		print("\033[32m\033[1mСкрытые эмоджи открыты!\033[0m")
			
	elif a =="4":
		file = list(csv.reader(open("system/files/player_thumbnails.csv", "r")))
		a = file[0].index("IsReward")
		
		for i in file:
			if i[a] == "true":
				i[a] = ""
			
		b = file[0].index("IsAvailableForOffers")
		
		for i in file:
			if i[b] == "true":
				i[b] = ""
	
		with open("csv/player_thumbnails.csv","w") as f:
			writer = csv.writer(f)
			for i in file:
				writer.writerow(i)
		print("\033[32m\033[1mИконки профиля открыты!\033[0m")
	elif a =="5":
		g = input("Работа с skins.csv\n1) Открыть скины (визуально)\n2) Убрать обводку\n3) Сделать 1 и 2 пункт\n0) Назад\n---> ")
	
		clear()
		if g == "1":
			file = list(csv.reader(open("system/files/skins.csv", "r")))
			a = file[0].index("ObtainType")
		
			for i in file:
				if i[a] == "":
					i[a] = "5"
					
				elif i[a] == "4":
					i[a] = "5"
	
				elif i[a] == "1":
					i[a] = "5"
	
				elif i[a] == "3":
					i[a] = "5"
	
				elif i[a] == "2":
					i[a] = "5"
	
				elif i[a] == "7":
					i[a] = "5"

				elif i[a] == "6":
					i[a] = "5"
	
			b = file[0].index("ObtainTypeCN")
	
			for i in file:
				if i[b] == "":
					i[b] = "5"
					
				elif i[b] == "4":
					i[b] = "5"

				elif i[b] == "1":
					i[b] = "5"
	
				elif i[b] == "3":
					i[b] = "5"
	
				elif i[b] == "2":
					i[b] = "5"
	
				elif i[b] == "7":
					i[b] = "5"
	
				elif i[b] == "6":
					i[b] = "5"
	
			with open("csv/skins.csv","w") as f:
				writer = csv.writer(f)
				for i in file:
					writer.writerow(i)
			print("\033[32m\033[1mВсе скины открыты!\033[0m")
	
		elif g == "2":
			file = list(csv.reader(open("system/files/skins.csv", "r")))
			a = file[0].index("OutlineShader")
		
			for i in file:
				if i[a] == "":
					i[a] = "sc3d/shaders/impostor"
	
			with open("csv/skins.csv","w") as f:
				writer = csv.writer(f)
				for i in file:
					writer.writerow(i)
			print("\033[32m\033[1mОбводка убрана!\033[0m")
	
		elif g == "3":
			file = list(csv.reader(open("system/files/skins.csv", "r")))
			a = file[0].index("ObtainType")
		
			for i in file:
				if i[a] == "":
					i[a] = "5"
					
				elif i[a] == "4":
					i[a] = "5"
	
				elif i[a] == "1":
					i[a] = "5"
	
				elif i[a] == "3":
					i[a] = "5"
	
				elif i[a] == "2":
					i[a] = "5"
	
				elif i[a] == "7":
					i[a] = "5"
	
				elif i[a] == "6":
					i[a] = "5"
	
			b = file[0].index("ObtainTypeCN")
	
			for i in file:
				if i[b] == "":
					i[b] = "5"
					
				elif i[b] == "4":
					i[b] = "5"

				elif i[b] == "1":
					i[b] = "5"
	
				elif i[b] == "3":
					i[b] = "5"
	
				elif i[b] == "2":
					i[b] = "5"
	
				elif i[b] == "7":
					i[b] = "5"
	
				elif i[b] == "6":
					i[b] = "5"
	
			с = file[0].index("OutlineShader")
		
			for i in file:
				if i[с] == "":
					i[с] = "sc3d/shaders/impostor"

			with open("csv/skins.csv","w") as f:
				writer = csv.writer(f)
				for i in file:
					writer.writerow(i)
			print("\033[32m\033[1mВсе скины открыты! Обводка убрана!\033[0m")
												
	elif a =="6":
		with open("system/files/locations.csv", "r") as f:
			f = list(reader(f))
			items = []
			disabled = f[0].index("Disabled")
			tid = f[0].index("TID")
	
			for i in range(2, len(f)):
				try:
					if f[i][disabled]:
						items.append(f[i][tid])
						f[i][disabled] = ""
						if f[i][tid] != "":
							if f[i][tid] not in TIDS:
								f[i][f[0].index("Map")], f[i][f[0].index("CommunityCredit")] = "DoesntExist", ""
							f[i][tid] = "DISABLED_" + f[i][tid]
						else:
							f[i][tid] = f[i][0]
	
				except:
					continue
	
			with open("csv/locations.csv", "w") as n:
				n = writer(n)
				for i in f:
					n.writerow(i)
				print("\033[32m\033[1mСкрытые карты открыты!\033[0m")
	
	elif a == "7":
		with open("system/files/cards.csv","r") as f:
			f = list(reader(f))
		
			for i in range(171,179):
				f[i][2] = "icon_sp_spawner_1"
		
			for i in range(2, len(f)):
				try:
					f[i][f[0].index("LockedForChronos")] = ""
				except: pass
		
		with open("csv/cards.csv", "w") as n:
			n = writer(n)
			for i in f:
				n.writerow(i)
		
		print("\033[32m\033[1mСкрытые пасивки и гаджеты открыты!\033[0m")
	
	elif a == "0":
		break
			