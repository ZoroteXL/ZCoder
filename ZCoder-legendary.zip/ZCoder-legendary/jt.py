bitmapsJson = {"id":0,"bitmaps":[{"textureIndex":0,"isRectangle":False,"points":[{"twip":[0,-1024],"uv":[1,1]},{"twip":[1024,-1024],"uv":[1,1]},{"twip":[1024,1],"uv":[1,1]},{"twip":[0,1],"uv":[1,1]}]}]}
bind = {"bindId":0,"blend":0,"name":None}
movieClip = {"id":1000,"frameRate":60,"binds":[{}],"data":{"frames":[]},"names":["GIF2SC"]}
transformsJson = {"name":None,"transforms":[{"bindIndex":0}]}
blahblah = {"id":1005,"frameRate":25,"binds":[{"bindId":1003,"blend":0,"name":"txt"}],"data":{"frames":[{"name":None,"transforms":[{"bindIndex":0}]}],"grids":[],"values":[]}}
blahblah1 = {"id":1001,"frameRate":60,"binds":[{"bindId":1000,"blend":0,"name":None},{"bindId":1005,"blend":0,"name":None}],"data":{"frames":[{"name":None,"transforms":[{"bindIndex":0,"matrix":[[0.2529296875,0,-130],[0,0.099609375,51]]},{"bindIndex":1,"matrix":[[0.2998046875,0,-130],[0,0.2998046875,-30]]}]}],"grids":[],"values":[]},"names":["GIF2SC"]}

